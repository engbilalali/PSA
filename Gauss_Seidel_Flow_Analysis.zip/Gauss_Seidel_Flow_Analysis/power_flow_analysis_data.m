clear
basemva = 100;  accuracy = 0.001; accel = 1.8; maxiter = 100;

%        IEEE 30-BUS TEST SYSTEM (American Electric Power)
%        Bus Bus  Voltage Angle   ---Load---- -------Generator----- Static Mvar
%        No  code Mag.    Degree  MW    Mvar  MW  Mvar Qmin Qmax    +Qc/-Ql
busdata=[1   1    1.00    0.0     0.0   0.0    0.0  0.0   0   0       0
         2   0    1.00    0.0     170  105.35  0.0  0.0   0   0       0
         3   0    1.00    0.0     200  123.94  0.0  0.0   0   0       0
         4   2    1.02    0.0     80    0.0    318  0.0   0   0       0];

%                                        Line code
%         Bus bus   R      X     1/2 B   = 1 for lines
%         nl  nr  p.u.   p.u.   p.u.     > 1 or < 1 tr. tap at bus nl
linedata=[1   2   0.3145   0.0524   0.0    1
          1   3   0.1938   0.0387   0.0    1
          2   4   0.1938   0.0387   0.0    1
          3   4   0.3311   0.0661   0.0    1];

lfybus                            % form the bus admittance matrix
lfgauss                % Load flow solution by Gauss-Seidel method
busout              % Prints the power flow solution on the screen
lineflow          % Computes and displays the line flow and losses
