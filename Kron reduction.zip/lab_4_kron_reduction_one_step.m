% Original Ybus matrix
Ybus = [0-9.8i,   0,       0+4i,      0+5i;
        0,         0-8.3i,  0+2.5i,    0+5i;
        0+4i,      0+2.5i,  0-14.5i,   0+8i;
        0+5i,      0+5i,    0+8i,      0+18i];

% Extracting submatrices
Y_upper_left = Ybus(1:2, 1:2);             % Upper left submatrix
Y_upper_right = Ybus(1:2, 3:4);            % Upper right submatrix
Y_lower_left = Ybus(3:4, 1:2);             % Lower left submatrix
Y_lower_right = Ybus(3:4, 3:4);            % Lower right submatrix

% Compute the inverse of the lower right 2x2 submatrix
pivot_point = inv(Y_lower_right);

% Compute the reduced Ybus matrix
Y_reduced = Y_upper_left - Y_upper_right * pivot_point * Y_lower_left;

% Display the reduced Ybus matrix
disp('Reduced Ybus matrix after Kron reduction:');
disp(Y_reduced);
