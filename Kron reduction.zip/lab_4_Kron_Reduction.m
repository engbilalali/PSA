% Original Ybus matrix
Ybus = [0-9.8i,   0,       0+4i,      0+5i;
        0,         0-8.3i,  0+2.5i,    0+5i;
        0+4i,      0+2.5i,  0-14.5i,   0+8i;
        0+5i,      0+5i,    0+8i,      0+18i];

% disp('Ybus = ');
% disp(Ybus);

% Extracting submatrices
Y_upper_left = Ybus(1:3, 1:3);     % Upper left submatrix
Y_upper_right = Ybus(1:3, 4);       % Upper right column vector
Y_lower_left = Y_upper_right.';     % Lower left row vector (transposed)
Y_lower_right = Ybus(4, 4);         % Lower right scalar

% % Displaying the submatrices
% disp('Y_upper_left = ');
% disp(Y_upper_left);
% disp('Y_upper_right = ');
% disp(Y_upper_right);
% disp('Y_lower_left = ');
% disp(Y_lower_left);
% disp('Y_lower_right = ');
% disp(Y_lower_right);

% Compute the inverse of the lower right scalar
pivot_point = inv(Y_lower_right);
% Display the pivot point
% disp('Pivot Point (Inverse of Y_lower_right) = ');
% disp(pivot_point);

% Compute the reduced Ybus matrix
Y_reduced = Y_upper_left - Y_upper_right * inv(Y_lower_right) * Y_lower_left;

% Display the reduced Ybus matrix
disp('Reduced Ybus matrix after Kron reduction:');
disp(Y_reduced);

% Compute the submatrices after eliminating bus 4
Y_upper_left_reduced = Y_reduced(1:2, 1:2);
Y_upper_right_reduced = Y_reduced(1:2, 3);
Y_lower_left_reduced = Y_upper_right_reduced.';
Y_lower_right_reduced = Y_reduced(3, 3);

% Compute the inverse of the lower right scalar
pivot_point_reduced = inv(Y_lower_right_reduced);

% Compute the reduced Ybus matrix after eliminating bus 3
Y_reduced_second = Y_upper_left_reduced - Y_upper_right_reduced * inv(Y_lower_right_reduced) * Y_lower_left_reduced;

% Display the reduced Ybus matrix after second Kron reduction
disp('Reduced Ybus matrix after second Kron reduction:');
disp(Y_reduced_second);

