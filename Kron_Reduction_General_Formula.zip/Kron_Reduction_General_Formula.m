% Ask the user if they want to input the Ybus matrix or use a pre-defined one
use_predefined = input('Do you want to use a pre-defined Ybus matrix? (yes/no): ', 's');

if strcmpi(use_predefined, 'yes')
    % Define the pre-defined Ybus matrix
    % Uncomment the following lines and specify your pre-defined Ybus matrix
    Ybus = [0-9.8i,   0,       0+4i,      0+5i;
            0,         0-8.3i,  0+2.5i,    0+5i;
            0+4i,      0+2.5i,  0-14.5i,   0+8i;
            0+5i,      0+5i,    0+8i,      0+18i];
else
    % Prompt the user for the size of the Ybus matrix
    n = input('Enter the size of the Ybus matrix: ');

    % Take input for the whole Ybus matrix
    fprintf('Enter the Ybus matrix (%dx%d):\n', n, n);
    Ybus = zeros(n);
    for i = 1:n
        for j = 1:n
            fprintf('Ybus(%d,%d): ', i, j);
            Ybus(i,j) = input('');
        end
    end
end

% Display the original Ybus matrix
fprintf('\nOriginal Ybus matrix:\n');
disp(Ybus);

eliminate_more = 'yes';
while strcmpi(eliminate_more, 'yes')
    % Ask the user which bus to eliminate
    bus_to_eliminate = input('Enter the bus number to eliminate: ');

    % Extract submatrices
    Y_upper_left = Ybus;
    Y_upper_left(bus_to_eliminate, :) = [];
    Y_upper_left(:, bus_to_eliminate) = [];
    Y_upper_right = Ybus(:, bus_to_eliminate);
    Y_upper_right(bus_to_eliminate, :) = [];
    Y_lower_left = Ybus(bus_to_eliminate, :);
    Y_lower_left(:, bus_to_eliminate) = [];
    Y_lower_right = Ybus(bus_to_eliminate, bus_to_eliminate);

    % Compute the inverse of the lower right submatrix
    pivot_point = inv(Y_lower_right);

    % Compute the reduced Ybus matrix
    Y_reduced = Y_upper_left - Y_upper_right * pivot_point * Y_lower_left;

    % Display the reduced Ybus matrix
    fprintf('\nReduced Ybus matrix after eliminating bus %d:\n', bus_to_eliminate);
    disp(Y_reduced);

    % Update Ybus for further eliminations
    Ybus = Y_reduced;

    % Ask the user if they want to eliminate more buses
    eliminate_more = input('Do you want to eliminate more buses? (yes/no): ', 's');
end
