% Test data
zdata_test = [0    3    0   0.1
              0    4    0   0.1
              1    3    0   0.25
              1    2    0   0.125
              1    4    0   0.4
              2    3    0   0.25
              2    4    0   0.2];

% Calculate Ybus
Ybus_result = ybus(zdata_test);
