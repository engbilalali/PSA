function [Ybus] = ybus(zdata)
% Function to compute the Bus Admittance Matrix (Ybus) from line data

nl = zdata(:,1);  % Starting bus numbers
nr = zdata(:,2);  % Ending bus numbers
R = zdata(:,3);   % Resistance
X = zdata(:,4);   % Reactance

nbr = length(zdata(:,1));  % Number of branches
nbus = max(max(nl), max(nr));  % Total number of buses

Z = R + 1j*X;  % Complex impedance
y = ones(nbr,1) ./ Z;  % Admittance of each branch

Ybus = zeros(nbus,nbus);  % Initialize Ybus to zeros

% Formation of off-diagonal elements
for k = 1:nbr
    if nl(k) > 0 && nr(k) > 0
        Ybus(nl(k),nr(k)) = Ybus(nl(k),nr(k)) - y(k);
        Ybus(nr(k),nl(k)) = Ybus(nl(k),nr(k));
    end
end

% Formation of diagonal elements
for n = 1:nbus
    for k = 1:nbr
        if nl(k) == n || nr(k) == n
            Ybus(n,n) = Ybus(n,n) + y(k);
        end
    end
end
